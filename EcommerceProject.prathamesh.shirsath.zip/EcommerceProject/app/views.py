from django.shortcuts import render,redirect
from django.views import View
from .models import Customer,Product,Cart,OrderPlaced
from .forms import CustomerRegistrationForm,CutomerProfileForm,ProductForm
from django.contrib import messages
from django.shortcuts import get_object_or_404
from django.db.models import Q
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from django.shortcuts import render
from .models import Product
from django.contrib.auth import authenticate, login
from .forms import LoginForm
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.urls import reverse
from django.contrib.auth.tokens import default_token_generator
from django.http import HttpResponse
import random
import string
from django.contrib.auth import login as auth_login
'''
"This class represents a view for displaying various categories of products on the homepage."
return: Rendering the home.html template with the retrieved products categorized by different categories as context.
'''
class ProductView(View):
    def get(self,request):
        topwears = Product.objects.filter(category='TW')
        bottomwears = Product.objects.filter(category='BW')
        sportwears = Product.objects.filter(category='SW')
        partywears = Product.objects.filter(category='PW')
        mobile = Product.objects.filter(category='M')
       # cart_count = Cart.objects.filter(user=request.user).count()
        return render(request,'app/home.html',{'topwears':topwears,'bottomwears':bottomwears,'mobile':mobile,
                                            'sportwears':sportwears,'partywears':partywears})
        
'''
"This function handles the search functionality where users can query for products based on title."
return: Rendering the search_results.html template with the filtered results based on the user's query.
'''
def search_view(request):
    query = request.GET.get('query')
    results = Product.objects.filter(title__icontains=query)
    return render(request, 'app/search_results.html', {'results': results})


'''
This class represents a view for displaying details of a specific product.
return: Rendering the productdetail.html template with details of the 
        requested product and a boolean indicating if the item is already present in the user's cart.
'''
@method_decorator(login_required,name='dispatch')
class ProductDetail(View):
    def get(self,request,pk):
        product = Product.objects.get(pk=pk)
        item_already_in_cart = False
        item_already_in_cart = Cart.objects.filter(Q(product=product.id) & Q(user=request.user)).exists()
        return render(request,'app/productdetail.html',{'product':product,'item_already_in_cart':item_already_in_cart})


'''
This function handles the addition of a product to the user's cart.
@login_required decorator is applied to enforce login requirement for accessing this view.
return: Redirecting the user to the cart page after adding the product to the cart.
'''
@login_required
def add_to_cart(request):
    user=request.user
    product_id = request.GET.get('product_id')
    product = Product.objects.get(id=product_id)
    reg = Cart(user=user,product=product)
    reg.save()
    return redirect('/cart')


'''
This function displays the user's cart, showing the products added by the user.
If the user is authenticated, it retrieves the cart items for the current logged-in user and calculates the total amount including shipping.
return: Rendering the addtocart.html template with cart items, total amount, and shipping charges if there are items in the cart. If the cart is empty, 
it renders the emptycart.html template.
'''
@login_required
def show_cart(request):
    if request.user.is_authenticated:
        #get the current login user and the show cart on the basis of the user id.
        user = request.user
        cart = Cart.objects.filter(user=user)
        amount = 0.0
        shipping_amount = 50
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user == user]
        #cart_count = Cart.objects.filter(user=request.user).count()
        if cart_product:
            for p in cart_product:
                tempamount = (p.quantity * float(p.product.discounted_price))
                amount +=tempamount
                total_amount = amount+shipping_amount
            return render(request,'app/addtocart.html',{'carts':cart,'amount':amount,'total_amount':total_amount})
        else:
            return render(request,"app/emptycart.html")


'''
This function handles increasing the quantity of a product in the user's cart.
return: It returns a JSON response containing the updated quantity, amount, 
and total amount after increasing the quantity of the product in the cart.
'''
@login_required
def plus_cart(request):
    if request.method == 'GET':
        product_id = request.GET['product_id']
        print(product_id)
        c = Cart.objects.get(Q(product=product_id) & Q(user=request.user))
        c.quantity+=1
        c.save()
        amount = 0.0
        shipping_amount = 50
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user ==request.user]
        for p in cart_product:
            tempamount = (p.quantity * float(p.product.discounted_price))
            amount +=tempamount
            total_amount = amount+shipping_amount
            data ={
                'quantity':c.quantity,
                'amount':amount,
                'total_amount' : total_amount 
            }
        return JsonResponse(data)


'''
This function handles decreasing the quantity of a product in the user's cart.
return: It returns a JSON response containing the updated quantity, amount, and 
total amount after decreasing the quantity of the product in the cart.
'''
@login_required
def minus_cart(request):
    if request.method == 'GET':
        product_id = request.GET['product_id']
        print(product_id)
        c = Cart.objects.get(Q(product=product_id) & Q(user=request.user))
        c.quantity -= 1
        if c.quantity < 1:  # Check if quantity becomes less than 1
            c.delete()  # Remove the cart item from the database
            data = {
                'removed': True  # Indicate that the item has been removed
            }
        else:
            c.save()
            amount = 0.0
            shipping_amount = 50
            total_amount = 0.0
            cart_product = Cart.objects.filter(user=request.user)
            for p in cart_product:
                tempamount = p.quantity * float(p.product.discounted_price)
                amount += tempamount
            total_amount = amount + shipping_amount
            data = {
                'quantity': c.quantity,
                'amount': amount,
                'total_amount': total_amount,
                'removed': False  # Indicate that the item has not been removed
            }
        return JsonResponse(data)


'''
This function handles the removal of a product from the user's cart.
return: It returns a JSON response containing the updated amount and 
total amount after removing the product from the cart.
'''
@login_required
def remove_cart(request):
    if request.method == 'GET':
        product_id = request.GET['product_id']
        print(product_id)
        c = Cart.objects.get(Q(product=product_id) & Q(user=request.user))
        c.delete()
        amount = 0.0
        shipping_amount = 50
        total_amount = 0.0
        cart_product = [p for p in Cart.objects.all() if p.user ==request.user]
        for p in cart_product:
            tempamount = (p.quantity * float(p.product.discounted_price))
            amount +=tempamount
            total_amount = amount+shipping_amount
            data ={
                'amount':amount,
                'total_amount' : total_amount 
            }
        return JsonResponse(data)


'''
This function retrieves the addresses associated with the current logged-in user.
return: Rendering the address.html template with the addresses associated with the current user.
'''
@login_required
def address(request):
    address = Customer.objects.filter(user=request.user)
    return render(request, 'app/address.html',{'address':address,'active':'btn btn-primary'})


'''
This function retrieves the orders placed by the current logged-in user.
return: Rendering the orders.html template with the orders placed by the current user.
'''
@login_required
def orders(request):
    order_placed=OrderPlaced.objects.filter(user=request.user)
    return render(request, 'app/orders.html',{'order_placed':order_placed})


'''
This function renders the change password form page.
return: Rendering the changepassword.html template for the user to change their password.
'''
@login_required
def change_password(request):
 return render(request, 'app/changepassword.html')


'''
This function handles the display of mobile products.
return: Rendering the mobile.html template with the filtered mobile products.
'''
def mobile(request,data=None):
    if data == None:
        mobile = Product.objects.filter(category="M")
    elif data == 'iphone' or data == 'redmi':
        mobile = Product.objects.filter(category="M").filter(brand=data)
    return render(request, 'app/mobile.html',{'mobile':mobile})


def topwear(request, data=None):
    if data == None:
        products = Product.objects.filter(category="TW")
    elif data == 'US POLO':
        products = Product.objects.filter(category="TW", brand=data)

    paginator = Paginator(products, 3)  # Paginate by 4 items per page

    page = request.GET.get('page')
    try:
        topwear = paginator.page(page)
    except PageNotAnInteger:
        # If page is not an integer, deliver first page.
        topwear = paginator.page(1)
    except EmptyPage:
        # If page is out of range (e.g. 9999), deliver last page of results.
        topwear = paginator.page(paginator.num_pages)

    return render(request, 'app/topwear.html', {'topwear': topwear})


def bottomwear(request, data=None):
    if data is None:
        bottomwear = Product.objects.filter(category="BW")
    elif data == 'Allen Solly':
        bottomwear = Product.objects.filter(category="BW", brand=data)

    paginator = Paginator(bottomwear, 3)  # Paginate by 4 items per page

    page = request.GET.get('page')
    try:
        bottomwear = paginator.page(page)
    except PageNotAnInteger:
        bottomwear = paginator.page(1)
    except EmptyPage:
        bottomwear = paginator.page(paginator.num_pages)

    return render(request, 'app/bottomwear.html', {'bottomwear': bottomwear})


def sportwear(request, data=None):
    if data is None:
        sportwear = Product.objects.filter(category="SW")
    elif data == 'Allen Solly':
        sportwear = Product.objects.filter(category="SW", brand=data)

    paginator = Paginator(sportwear, 3)  # Paginate by 4 items per page

    page = request.GET.get('page')
    try:
        sportwear = paginator.page(page)
    except PageNotAnInteger:
        sportwear = paginator.page(1)
    except EmptyPage:
        sportwear = paginator.page(paginator.num_pages)

    return render(request, 'app/sportwear.html', {'sportwear': sportwear})

def partywear(request, data=None):
    if data is None:
        partywear = Product.objects.filter(category="PW")
    elif data == 'Allen Solly':
        partywear = Product.objects.filter(category="PW", brand=data)

    paginator = Paginator(partywear, 3)  # Paginate by 4 items per page

    page = request.GET.get('page')
    try:
        partywear = paginator.page(page)
    except PageNotAnInteger:
        partywear = paginator.page(1)
    except EmptyPage:
        partywear = paginator.page(paginator.num_pages)

    return render(request, 'app/partywear.html', {'partywear': partywear})

'''
This class-based view handles the registration process for customers.
Validates the submitted form data.
return: Rendering the customerregistration.html template with the registration form.
'''

# class CustomerRegistration(View):
#     def get(self,request):
#         form=CustomerRegistrationForm()
#         return render(request,'app/customerregistration.html',{'form':form})
#     def post(self,request):
#         form = CustomerRegistrationForm(request.POST)
#         if form.is_valid():
#             messages.success(request,"congratulations !!! Registered Successfully")
#             form.save()
#         return render(request,'app/customerregistration.html',{'form':form})

class CustomerRegistration(View):
    def get(self, request):
        form = CustomerRegistrationForm()
        return render(request, 'app/customerregistration.html', {'form': form})

    def post(self, request):
        form = CustomerRegistrationForm(request.POST)
        if form.is_valid():
            # Save user
            user = form.save(commit=False)
            user.save() 
            # Get role from form data
            role = form.cleaned_data['role']
            # Create Customer instance
            customer = Customer.objects.create(
                user=user,
                role=role,
            )
            messages.success(request, "Congratulations! Registered Successfully")
            return redirect('customerregistration')  # Redirect to login page after successful registration
        else:
            messages.error(request, "Registration failed. Please correct the errors below.")
            return render(request, 'app/customerregistration.html', {'form': form})


#made the comment
# def custom_login(request):
#     if not request.user.is_authenticated:
#         if request.method == 'POST':
#             fa = LoginForm(request=request, data=request.POST)
#             if fa.is_valid():
#                 uname = fa.cleaned_data['username']
#                 upass = fa.cleaned_data['password']
#                 user = authenticate(username=uname, password=upass)
#                 if user is not None:
#                     login(request, user)
#                     messages.success(request,"successfully register!!!")
#                     return redirect('profile')
#         else:
#             fa = LoginForm()
#         return render(request, 'app/login.html', {'form': fa})
#     else:
#         return redirect('profile')


'''
    Generate a 6-digit OTP using digits.
    Returns:str: A string containing a 6-digit OTP.
'''
def generate_otp():
    otp = ''.join(random.choices(string.digits, k=6))
    return otp


'''
    Handles custom login functionality.
    If the user is not authenticated, handles the login form submission.
    If the user is authenticated, redirects to the profile page.
    Returns:
    HttpResponse: Renders the login form if the user is not authenticated,
                  otherwise redirects to the profile page.
'''
def custom_login(request):
    if not request.user.is_authenticated:
        if request.method == 'POST':
            fa = LoginForm(request=request, data=request.POST)
            if fa.is_valid():
                uname = fa.cleaned_data['username']
                upass = fa.cleaned_data['password']
                user = authenticate(username=uname, password=upass)
                if user is not None:
                    # Generate OTP
                    otp = generate_otp()
                    # You can do something with this OTP, such as send it via SMS or email
                    print("Generated OTP:", otp)
                    # Store the OTP in the user session for validation later
                    request.session['otp'] = otp
                    request.session['username'] = uname  # Store username for OTP validation
                    request.session['password']=upass
                    
                    # Redirect to OTP verification page
                    return redirect('verify_otp')
        else:
            fa = LoginForm()
        return render(request, 'app/login.html', {'form': fa})
    else:
        return redirect('login')


'''
    Verify the entered OTP and authenticate the user if the OTP is correct.
    If the entered OTP matches the stored OTP in the session, authenticate the user
    and redirect to the profile page. If the OTP is incorrect, display an error message.
    Returns:
    HttpResponse: Renders the OTP verification page with appropriate messages.
'''
def verify_otp(request):
    if request.method == 'POST':
        entered_otp = request.POST.get('otp')
        stored_otp = request.session.get('otp')
        
        print("Entered OTP:", entered_otp)
        print("Stored OTP:", stored_otp)
        
        if entered_otp == stored_otp:
            # OTP matched, proceed with login
            uname = request.session.get('username')
            upass = request.session.get('password')
            print(uname)
            print(upass)
            user = authenticate(username=uname, password=upass)
            print("Authenticated User:", user)
            if user is not None:
                    print("role",user.customer.role)
                    if user.customer.role == 'customer':
                        login(request, user)
                        messages.success(request, "Successfully logged in!")
                        return redirect('profile')  # Redirect to customer profile
                    elif user.customer.role == 'seller':
                        login(request, user)
                        messages.success(request, "Successfully logged in!")
                        return redirect('seller_profile')  # Redirect to seller profile
                    else:
                        messages.error(request, "Role not defined for user.")
            else:
                messages.error(request, "Authentication failed. User not found.")
        else:
            messages.error(request, "Invalid OTP. Please try again.")
            print("OTP verification failed.")
    return render(request, 'app/verify_otp.html')
    
    
@login_required
def seller_profile(request):
    # Your logic for seller profile view
    return render(request, 'app/seller_profile.html')

'''
This function handles the checkout process.
return:Renders the checkout.html template with the user's addresses, total amount, amount, and cart items.
'''
@login_required
def checkout(request):
    user=request.user
    address= Customer.objects.filter(user=user)
    print(address)
    cart_items = Cart.objects.filter(user=user)
    amount = 0.0
    shipping_amount = 50
    total_amount = 0.0
    cart_product = [p for p in Cart.objects.all() if p.user ==request.user]
    if cart_product:
        for p in cart_product:
          tempamount = (p.quantity * float(p.product.discounted_price))
          amount +=tempamount
        total_amount = amount+shipping_amount
    return render(request, 'app/checkout.html',{'address':address,'total_amount':total_amount,'amount':amount,'cart_items':cart_items})


'''
This function handles the completion of the payment process.
Iterates over each item in the cart, creates an OrderPlaced object for each item, 
saves it to the database, and deletes the item from the cart.
return: Redirecting the user to the orders page after completing the payment.
'''
@login_required
def payment_done(request):
    user = request.user
    cart = Cart.objects.filter(user=user)
    for c in cart:
        reg=OrderPlaced(user=user,product=c.product,quantity=c.quantity)
        reg.save()
        c.delete()
    return redirect("orders")


'''
This class-based view represents the user's profile page.
@method_decorator(login_required, name='dispatch') decorator is applied to enforce login requirement for accessing this view.
return: Rendering the profile.html template with the profile form .
'''
@method_decorator(login_required,name='dispatch')
class ProfileView(View):
    def get(self, request):
        # Check if the user already has a profile
        user_profile, created = Customer.objects.get_or_create(user=request.user)
        
        # If the profile is newly created, initialize the form with empty data
        if created:
            form = CutomerProfileForm()
        else:
            # Populate the form with the user's profile data as initial data
            form = CutomerProfileForm(initial={
                'name': user_profile.name,
                'locality': user_profile.locality,
                'city': user_profile.city,
                'state': user_profile.state,
                'zipcode': user_profile.zipcode,
            })
            
        return render(request, 'app/profile.html', {'form': form, 'active': 'btn btn-primary'})
    
    
    '''
    This post method handles the submission of the user's profile form.
    Validates the submitted form data.
    return: Rendering the profile.html template with the updated form.
    '''
    def post(self, request):
        form = CutomerProfileForm(request.POST)
        if form.is_valid():
            usr = request.user
            name = form.cleaned_data['name']
            locality = form.cleaned_data['locality']
            city = form.cleaned_data['city']
            state = form.cleaned_data['state']
            zipcode = form.cleaned_data['zipcode']
            user_profile, created = Customer.objects.get_or_create(user=usr)
            user_profile.name = name
            user_profile.locality = locality
            user_profile.city = city
            user_profile.state = state
            user_profile.zipcode = zipcode
            user_profile.save()
            messages.success(request, "Congratulations, profile updated successfully!")
        return render(request, 'app/profile.html', {'form': form}) 

@login_required
def seller_profile(request):
    seller = request.user
    print(seller)
    products = Product.objects.filter(seller=seller)
    print("products",products)
    return render(request,'app/seller_profile.html',{'products': products})


@login_required
def add_product(request):
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES)
        if form.is_valid():
            product = form.save(commit=False)
            product.seller = request.user  # Set the seller to the logged-in user
            product.save()
            return redirect('seller_profile')  # Redirect to the product list page
    else:
        form = ProductForm()
    return render(request, 'app/add_product.html', {'form': form})

@login_required
def edit_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    if request.method == 'POST':
        form = ProductForm(request.POST, request.FILES, instance=product)
        if form.is_valid():
            form.save()
            # Redirect to the seller profile page after updating the product
            return redirect('seller_profile')
    else:
        form = ProductForm(instance=product)
    return render(request, 'app/edit_product.html', {'form': form})

@login_required
def delete_product(request, product_id):
    product = get_object_or_404(Product, id=product_id)
    product.delete()
    # Redirect to a relevant page after deletion
    return redirect('seller_profile')  # You can adjust the redirect URL as needed

@login_required
def seller_orders(request):
    # Assuming 'request.user' is the seller
    seller_products = request.user.product_set.all()  # Get products of the seller
    orders = OrderPlaced.objects.filter(product__in=seller_products)
    return render(request, 'app/seller_orders.html', {'orders': orders})